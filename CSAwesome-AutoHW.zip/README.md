# CSAwesome-AutoHW
A chrome extension that completes all the multiple choice exercises on the runestone.academy website.

// CODE BOXES

const runButtons = document.getElementsByClassName("btn btn-success run-button");

for (var button of runButtons) {
    button.click();
}

